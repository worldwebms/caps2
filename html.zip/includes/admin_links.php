	<tr> 
		<td background="images/horizontal_line.gif">&nbsp;</td>
		<td colspan="2" background="images/horizontal_line.gif" class="text">&gt; 
			<a href="index1.php?client_id=<?php echo $client_id; ?>"><font color="#B9E9FF">General</font></a><img src="images/spacer.gif" width="39" height="10">&gt; 
			<a href="contact.php?client_id=<?php echo $client_id; ?>"><font color="#B9E9FF">Contact</font></a><img src="images/spacer.gif" width="39" height="10">&gt; 
			<a href="email.php?client_id=<?php echo $client_id; ?>"><font color="#B9E9FF">Email</font></a><img src="images/spacer.gif" width="39" height="10">&gt;
			<a href="technical.php?client_id=<?php echo $client_id; ?>"><font color="#B9E9FF">Domains</font></a><img src="images/spacer.gif" width="39" height="10">&gt;  
			<a href="job_control.php?client_id=<?php echo $client_id; ?>"><font color="#B9E9FF">Job Control</font></a>
		</td>
	</tr>