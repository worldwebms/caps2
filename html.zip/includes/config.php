<?php

$userName = "capsuser";
$hostName = "localhost";
$password = "ww4ims";
$database = "caps";

//directory folders settings
$logDir = "/vhosts/office.pac.eco/www/html/caps/logs";
$invoiceDir = "/vhosts/office.pac.eco/www/html/caps/invoices";
$attachDir = "/vhosts/office.pac.eco/www/html/caps/attachments";
$templateDir = "/vhosts/office.pac.eco/www/html/caps/includes";

//mail host name
$mailHostName = "202.191.100.8";
$clientMailServer = "vmail.worldwebms.com";
$logEmail = "chris@worldwebms.com";

?>
