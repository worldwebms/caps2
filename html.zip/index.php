<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>CAPS | WorldWeb Management Services</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="includes/caps_styles.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#006699" leftmargin="0" topmargin="0">
<table width="100%" height="53" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td height="53"><img src="images/worldweb-logo.png" border="0" height="40"></td>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="13" valign="top" class="bluesmall"> 
            <div align="right"><img src="images/spacer.gif" width="40" height="13"></div></td>
        </tr>
        <tr>
		<form name="login" action="access.php" method="post">
          <td height="40" valign="bottom">
            <div>
              <div align="right"><span class="footer">u:</span> 
			    <input id="uid" type="Text" name="uid" size="20" class="smallwhite">
                <span class="footer">p:</span>
                <input name="pwd" type="password" class="smallwhite" size="20">
                <span class="blacksmall">
				<input type="submit" class="submit" value="GO"> 
                <img src="images/spacer.gif" width="15" height="8"></span> 
              </div>
            </div>
		  </td>
		  </form>
        </tr>
      </table></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="1%"><img src="images/spacer.gif" width="8" height="27"></td>
    <td width="99%" class="clienttitle">&nbsp;</td>
  </tr>
</table>
<script type="text/javascript" language="JavaScript">
document.getElementById( "uid" ).focus();
</script>
</body>
</html>
